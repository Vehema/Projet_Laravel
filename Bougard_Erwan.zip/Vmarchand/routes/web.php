<?php

use App\Http\Controllers\CustomerController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\PostController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/
Route::get('/', function () {
    return view('home');
});
//Route::get('/', [PostController::class,'index']);
//Route::get('{post}', [PostController::class,'show']);
Route::resource("posts", PostController::class);
Route::resource("customers", CustomerController::class);
Route::resource("products", ProductController::class);
Route::get('/search', [PostController::class, 'search']);
Route::get('/search2', [CustomerController::class, 'search']);
Route::get('/search3', [ProductController::class, 'search']);
