<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;

class ProductController extends Controller
{
    public function index()
    {
        $products = Product::latest()->get();

        return view("products.index", compact("products"));
    }
    public function show(Product $product)
    {
        return view("products.show", compact("product"));
       
    }
    public function search(Request $request)
    {
     $products = Product::where('name','LIKE',"%{$request->q}%")->get();
     
      return view("products.index", compact("products"));
    }
    public function create() 
    {
        return view("products.edit");
    }
    public function store(Request $request)
    {
        //Validation Vma130400.
        $this->validate($request, [
            'name' => 'bail|required|string|max:255',
            'price'=>'bail|required|integer',
            "stock" => 'bail|required|integer',
            "content" => 'bail|required', 
        ]);
        //save 
        Product::create([
            "name" => $request->name,
            'price'=> $request->price,
            "stock" => $request->stock,
            "content" => $request->content,
        ]);
        //Return index
        return redirect(route("products.index"));
    }

    public function edit(Product $product) 
    { 
        return view("products.edit", compact("product"));
    }
    public function update(Request $request, Product $product) 
    { 
    // Les règles de validation
    $rules = [
        'name' => 'bail|required|string|max:255',
        'price'=>'bail|required|integer',
        "stock" => 'bail|required|integer',
        "content" => 'bail|required',
    ];

    // 3. maj Post
    $product->update([
        "name" => $request->name,
        "price"=> $request->price,
        "stock" => $request->stock,
        "content" => $request->content
    ]);

    // 4. On affiche le Post 
    return redirect(route("products.show", $product));
    }
    public function destroy(Product $product) 
    { 
        $product->delete();
        return redirect(route('products.index'));
    }
}


