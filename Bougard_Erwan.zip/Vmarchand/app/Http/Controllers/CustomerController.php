<?php

namespace App\Http\Controllers;

use App\Models\Customer;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class CustomerController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $customers = Customer::latest()->get();
        return view("customers.index", compact("customers"));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view("customers.edit");
    }

    /**
     * Store a newly created resource in storage.
     */
    public function search(Request $request)
    {
     $customers = customer::where('name','LIKE',"%{$request->q}%")->get();
     
      return view("customers.index", compact("customers"));
    }
    public function store(Request $request)
    {
         //Validation Vma130400.
         $this->validate($request, [
            'name' => 'bail|required|string|max:255',
            "email" => 'bail|required|string|max:1024',
            "description" => 'bail',
        ]);
       
        //save 
        Customer::create([
            "name" => $request->name,
            "email" => $request->email,
            "description" => $request->description,
        ]);
        //Return index
        return redirect(route("customers.index"));
    }

    /**
     * Display the specified resource.
     */
    public function show(Customer $customer)
    {
        return view("customers.show", compact("customer"));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Customer $customer)
    {
        return view("customers.edit", compact("customer"));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Customer $customer)
    {
         // Les règles de validation
    $rules = [
        'name' => 'bail|required|string|max:255',
        'email'=> 'bail|required|max:255',
        "description" => 'bail|required',
    ];

    // 3. maj Post
    $customer->update([
        "name" => $request->name,
        "email" => $request->email,
        "description" => $request->description,
    ]);

    // 4. On affiche le Post 
    return redirect(route("customers.show", $customer));
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Customer $customer)
    {
        $customer->delete();
        return redirect(route('customers.index'));
    }
}
