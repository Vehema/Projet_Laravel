<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Post;
use Illuminate\Support\Facades\Storage;

class PostController extends Controller
{
    public function index()
    {

        $posts = Post::latest()->get();

        return view("posts.index", compact("posts"));
       // return view('welcome',[
        //   'articles'=> Post::all()
       // ]);
    }
    public function show(Post $post)
    {
        return view("posts.show", compact("post"));
        //FindOrFail
      // return view('article',[
       // 'article'=> $post
       //]);
    }
    public function search(Request $request)
    {
     $posts = Post::where('type','LIKE',"%{$request->q}%")->get();
     
      return view("posts.index", compact("posts"));
    }
    public function create() 
    {
        return view("posts.edit");
    }
    public function store(Request $request)
    {
        //Validation Vma130400.
        $this->validate($request, [
            'title' => 'bail|required|string|max:255',
            'type'=>'bail|required|string|max:255',
            "picture" => 'bail|required|image|max:1024',
            "content" => 'bail|required',
        ]);
        //upload img
        $chemin_image = $request->picture->store("posts");
        //save 
        Post::create([
            "title" => $request->title,
            'type'=> $request->type,
            "picture" => $chemin_image,
            "content" => $request->content,
        ]);
        //Return index
        return redirect(route("posts.index"));
    }

    public function edit(Post $post) 
    { 
        return view("posts.edit", compact("post"));
    }
    public function update(Request $request, Post $post) 
    { 
    // Les règles de validation
    $rules = [
        'title' => 'bail|required|string|max:255',
        'type'=>'bail|required|string|max:255',
        "content" => 'bail|required',
    ];

    // Si new image 
    if ($request->has("picture")) {
        // On ajoute la règle de validation pour image
        $rules["picture"] = 'bail|required|image|max:1024';
    }

    $this->validate($request, $rules);

    // 2. On upload l'image dans "/storage/app/public/posts"
    if ($request->has("picture")) {

        //On delete l'ancienne image Vma130420
        Storage::delete($post->picture);

        $chemin_image = $request->picture->store("posts");
    }

    // 3. maj Post
    $post->update([
        "title" => $request->title,
        "type"=> $request->type,
        "picture" => isset($chemin_image) ? $chemin_image : $post->picture,
        "content" => $request->content
    ]);

    // 4. On affiche le Post 
    return redirect(route("posts.show", $post));
    }
    public function destroy(Post $post) 
    { 
        Storage::delete($post->picture);
        $post->delete();
        return redirect(route('posts.index'));
    }
}
