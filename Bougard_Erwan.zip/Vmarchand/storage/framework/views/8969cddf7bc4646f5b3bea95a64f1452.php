
<?php $__env->startSection("title", $product->name); ?>
<?php $__env->startSection("content"); ?>
	
	<h1>Nom du produit : <?php echo e($product->name); ?></h1>
	
	<h1>Prix : <?php echo e($product->price); ?></h1>

	<div>Produit en stock : <?php echo e($product->stock); ?></div>
    <div>Description du produit : <?php echo e($product->content); ?></div>


	<p><a href="<?php echo e(route('products.index')); ?>" title="Retourner aux produit" >Retourner aux produit</a></p>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Vmarchand\Vmarchand\resources\views/products/show.blade.php ENDPATH**/ ?>