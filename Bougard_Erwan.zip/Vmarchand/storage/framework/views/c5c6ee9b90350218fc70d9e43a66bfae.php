
<?php $__env->startSection("title", $customer->name); ?>
<?php $__env->startSection("content"); ?>

	<h1>Nom du client : <?php echo e($customer->name); ?></h1>
	
	<h1>Email du client : <?php echo e($customer->email); ?></h1>
	<p>Description</p>
	<div><?php echo e($customer->description); ?></div>

	<p><a href="<?php echo e(route('customers.index')); ?>" title="Retourner aux documents" >Retourner aux documents</a></p>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Vmarchand\Vmarchand\resources\views/customers/show.blade.php ENDPATH**/ ?>