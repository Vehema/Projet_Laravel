<!DOCTYPE html>
<html lang="fr">
<head>
	<meta charset="utf-8">
	<?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.css', 'resources/js/app.js']); ?>
	<!-- Le titre de la page -->
	<title><?php echo $__env->yieldContent("title"); ?></title>
</head>
<body class="bg-dark">
	<div class="bg-dark text-secondary px-4 py-5 text-center">
		<div class="py-5">
		  <!-- Le contenu -->
			<?php echo $__env->yieldContent("content"); ?>
		</div>
	  </div>
<script src="<?php echo e(asset("js/app.js")); ?>"></script>
</body>
</html><?php /**PATH C:\wamp64\www\Vmarchand\Vmarchand\resources\views/layouts/app.blade.php ENDPATH**/ ?>