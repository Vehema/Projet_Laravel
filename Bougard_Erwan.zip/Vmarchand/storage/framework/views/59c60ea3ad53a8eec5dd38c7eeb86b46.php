
<?php $__env->startSection("title", "Editer un document"); ?>
<?php $__env->startSection("content"); ?>

	<h1>Editer un document client </h1>

	<!-- Si nous avons un doc $customer -->
	<?php if(isset($customer)): ?>

	<!-- Le formulaire est géré par la route "customer.update" -->
	<form method="POST" action="<?php echo e(route('customers.update', $customer)); ?>" enctype="multipart/form-data" >

		<!-- <input type="hidden" name="_method" value="PUT"> -->
		<?php echo method_field('PUT'); ?>

	<?php else: ?>

	<!-- Le formulaire est géré par la route "customers.store" -->
	<form method="POST" action="<?php echo e(route('customers.store')); ?>" enctype="multipart/form-data" >

	<?php endif; ?>

		<!-- Le token CSRF -->
		<?php echo csrf_field(); ?>
		
		<p>
			<label for="name" >Nom</label><br/>

			<!-- S'il y a un $customer->title, on complète la valeur de l'input -->
			<input type="text" name="name" value="<?php echo e(isset($customer->name) ? $customer->name : old('name')); ?>"  id="name" placeholder="Le nom du client" >

			<!-- Le message d'erreur pour "nom" -->
			<?php $__errorArgs = ["name"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			<div><?php echo e($message); ?></div>
			<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
		</p>

        <p>
			<label for="email" >email</label><br/>

			<!-- S'il y a un $customer->email, on complète la valeur de l'input -->
			<input type="text" name="email" value="<?php echo e(isset($customer->email) ? $customer->email : old('email')); ?>"  id="email" placeholder="L'email du client" >

			<!-- Le message d'erreur pour "nom" -->
			<?php $__errorArgs = ["email"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			<div><?php echo e($message); ?></div>
			<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
		</p>
		
		<p>
			<label for="description" >Description</label><br/>

			<!-- S'il y a un $customer->description, on complète la valeur du textarea -->
			<textarea name="description" id="description" lang="fr" rows="10" cols="50" placeholder="Les informations du client" ><?php echo e(isset($customer->description) ? $customer->description : old('description')); ?></textarea>

			<!-- Le message d'erreur pour "description" -->
			<?php $__errorArgs = ["description"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			<div><?php echo e($message); ?></div>
			<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
		</p>

		<input type="submit" name="valider" value="Valider" >

	</form>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Vmarchand\Vmarchand\resources\views/customers/edit.blade.php ENDPATH**/ ?>