
<?php $__env->startSection("title", $post->title); ?>
<?php $__env->startSection("content"); ?>

	<h1>Titre du document : <?php echo e($post->title); ?></h1>

	<p>Type de document : <?php echo e($post->type); ?></p>
	<p>Apercu du document </p>
	<img src="<?php echo e(asset('storage/'.$post->picture)); ?>" alt="Image de couverture" style="max-width: 300px;">
	<p>Description du document</p>
	<div><?php echo e($post->content); ?></div>

	<p><a href="<?php echo e(route('posts.index')); ?>" title="Retourner aux articles" >Retourner aux documents</a></p>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Vmarchand\Vmarchand\resources\views/posts/show.blade.php ENDPATH**/ ?>