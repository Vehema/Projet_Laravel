
<?php $__env->startSection("title", "Editer un document"); ?>
<?php $__env->startSection("content"); ?>

	<h1>Editer un produit </h1>

	<!-- Si nous avons un doc $customer -->
	<?php if(isset($product)): ?>

	<!-- Le formulaire est géré par la route "products.update" -->
	<form method="POST" action="<?php echo e(route('products.update', $product)); ?>" enctype="multipart/form-data" >

		<!-- <input type="hidden" name="_method" value="PUT"> -->
		<?php echo method_field('PUT'); ?>

	<?php else: ?>

	<!-- Le formulaire est géré par la route "products.store" -->
	<form method="POST" action="<?php echo e(route('products.store')); ?>" enctype="multipart/form-data" >

	<?php endif; ?>

		<!-- Le token CSRF -->
		<?php echo csrf_field(); ?>
		
		<p>
			<label for="name" >Nom</label><br/>

			<!-- S'il y a un $customer->title, on complète la valeur de l'input -->
			<input type="text" name="name" value="<?php echo e(isset($product->name) ? $product->name : old('name')); ?>"  id="name" placeholder="Le nom du produit" >

			<!-- Le message d'erreur pour "nom" -->
			<?php $__errorArgs = ["name"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			<div><?php echo e($message); ?></div>
			<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
		</p>

        <p>
			<label for="price" >prix</label><br/>

			<!-- S'il y a un $products->price, on complète la valeur de l'input -->
			<input type="text" name="price" value="<?php echo e(isset($product->price) ? $product->price : old('price')); ?>"  id="price" placeholder="le prix du produit" >

			<!-- Le message d'erreur pour "nom" -->
			<?php $__errorArgs = ["price"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			<div><?php echo e($message); ?></div>
			<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
		</p>
        <p>
			<label for="stock" >Stock</label><br/>

			<!-- S'il y a un $products->stock, on complète la valeur de l'input -->
			<input type="text" name="stock" value="<?php echo e(isset($product->stock) ? $product->stock : old('stock')); ?>"  id="stock" placeholder="le nombre de produit en stock" >

			<!-- Le message d'erreur pour "stock" -->
			<?php $__errorArgs = ["stock"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			<div><?php echo e($message); ?></div>
			<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
		</p>
		
		<p>
			<label for="content" >Description</label><br/>

			<!-- S'il y a un $product->content, on complète la valeur du textarea -->
			<textarea name="content" id="content" lang="fr" rows="10" cols="50" placeholder="Les informations du produit" ><?php echo e(isset($product->content) ? $product->content : old('content')); ?></textarea>

			<!-- Le message d'erreur pour "description" -->
			<?php $__errorArgs = ["content"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			<div><?php echo e($message); ?></div>
			<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
		</p>

		<input type="submit" name="valider" value="Valider" >

	</form>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Vmarchand\Vmarchand\resources\views/products/edit.blade.php ENDPATH**/ ?>