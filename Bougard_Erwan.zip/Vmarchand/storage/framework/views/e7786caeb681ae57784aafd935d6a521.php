
<?php $__env->startSection("title", "Editer un document"); ?>
<?php $__env->startSection("content"); ?>

	<h1>Editer un document personnel</h1>

	<!-- Si nous avons un doc $post -->
	<?php if(isset($post)): ?>

	<!-- Le formulaire est géré par la route "posts.update" -->
	<form method="POST" action="<?php echo e(route('posts.update', $post)); ?>" enctype="multipart/form-data" >

		<!-- <input type="hidden" name="_method" value="PUT"> -->
		<?php echo method_field('PUT'); ?>

	<?php else: ?>

	<!-- Le formulaire est géré par la route "posts.store" -->
	<form method="POST" action="<?php echo e(route('posts.store')); ?>" enctype="multipart/form-data" >

	<?php endif; ?>

		<!-- Le token CSRF -->
		<?php echo csrf_field(); ?>
		
		<p>
			<label for="title" >Titre</label><br/>

			<!-- S'il y a un $post->title, on complète la valeur de l'input -->
			<input type="text" name="title" value="<?php echo e(isset($post->title) ? $post->title : old('title')); ?>"  id="title" placeholder="Le titre du post" >

			<!-- Le message d'erreur pour "title" -->
			<?php $__errorArgs = ["title"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			<div><?php echo e($message); ?></div>
			<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
		</p>
			<!-- S'il y a un $post->type, on complète la valeur de l'input -->
		<p>
			<label for="type" >Type</label><br/>

			<!-- S'il y a un $post->type, on complète la valeur de l'input -->
			<input type="text" name="type" value="<?php echo e(isset($post->type) ? $post->type : old('type')); ?>"  id="type" placeholder="Le type du post" >

			<!-- Le message d'erreur pour "type" -->
			<?php $__errorArgs = ["type"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			<div><?php echo e($message); ?></div>
			<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
		</p>

		<!-- S'il y a une image $post->picture, on l'affiche -->
		<?php if(isset($post->picture)): ?>
		<p>
			<span>Image actuelle</span><br/>
			<img src="<?php echo e(asset('storage/'.$post->picture)); ?>" alt="image actuelle" style="max-height: 200px;" >
		</p>
		<?php endif; ?>

		<p>
			<label for="picture" >image</label><br/>
			<input type="file" name="picture" id="picture" >

			<!-- Le message d'erreur pour "picture" -->
			<?php $__errorArgs = ["picture"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			<div><?php echo e($message); ?></div>
			<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
		</p>
		<p>
			<label for="content" >Contenu</label><br/>

			<!-- S'il y a un $post->content, on complète la valeur du textarea -->
			<textarea name="content" id="content" lang="fr" rows="10" cols="50" placeholder="Le contenu du post" ><?php echo e(isset($post->content) ? $post->content : old('content')); ?></textarea>

			<!-- Le message d'erreur pour "content" -->
			<?php $__errorArgs = ["content"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			<div><?php echo e($message); ?></div>
			<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
		</p>

		<input type="submit" name="valider" value="Valider" >

	</form>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Vmarchand\Vmarchand\resources\views/posts/edit.blade.php ENDPATH**/ ?>