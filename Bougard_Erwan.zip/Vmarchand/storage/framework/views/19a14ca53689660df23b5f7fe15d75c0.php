
<?php $__env->startSection("title", "Tous les documents"); ?>
<?php $__env->startSection("content"); ?>

	<h1>Tous vos documents</h1>
	<!-- Recherche de type de documents-->
	<div>
		<form action="/search" method="GET" role="search">
			<div>
			<p>Rechercher un type de document</p>
			<input type="text" name="q" placeholder="Exemple : Facture">
			<button type="submit">Go!</button>
			</div>
		</form>
	</div>
	<div class="my-3">
	<p>
		<!-- Lien pour créer un nouveau doc : "posts.create" -->
		<button type="button" class="btn btn-outline-info btn-lg px-4 me-sm-3 fw-bold">
		<a href="<?php echo e(route('posts.create')); ?>" title="Créer un article" >Créer un nouveau document</a>
		</button>
	</p>
	</div>
	<!-- Le tableau pour lister les articles/posts -->
	<div class="col-lg-2 mx-auto">
	<table border="3" >
		<thead>
			<tr>
				<th>Titre</th>
				<th>Type</th>
				<th colspan="3" >Opérations</th>
			</tr>
		</thead>
		<tbody>
			<!-- On parcourt la collection de Post -->
			<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td>
					<!-- Lien pour afficher un Post : "posts.show" -->
					<a href="<?php echo e(route('posts.show', $post)); ?>" title="Lire l'article" ><?php echo e($post->title); ?></a>
				</td>
				<td>
					<p><?php echo e($post->type); ?></p>
				</td>
				<td>
					<!-- Lien pour modifier un Post : "posts.edit" -->
					<a href="<?php echo e(route('posts.edit', $post)); ?>" title="Modifier l'article" >Modifier</a>
				</td>
				<td>
					<!-- Formulaire pour supprimer un Post : "posts.destroy" -->
					<form method="POST" action="<?php echo e(route('posts.destroy', $post)); ?>" >
						<!-- CSRF token -->
						<?php echo csrf_field(); ?>
						<!-- <input type="hidden" name="_method" value="DELETE"> -->
						<?php echo method_field("DELETE"); ?>
						<input type="submit" value="x Supprimer" >
					</form>
				</td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
	<p><a href="/" title="Retourner a l'accueil" >Retourner a l'accueil</a></p>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Vmarchand\Vmarchand\resources\views/posts/index.blade.php ENDPATH**/ ?>