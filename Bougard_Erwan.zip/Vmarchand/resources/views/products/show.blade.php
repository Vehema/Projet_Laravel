@extends("layouts.app")
@section("title", $product->name)
@section("content")
	
	<h1>Nom du produit : {{ $product->name }}</h1>
	
	<h1>Prix : {{ $product->price }}</h1>

	<div>Produit en stock : {{ $product->stock }}</div>
    <div>Description du produit : {{ $product->content }}</div>


	<p><a href="{{ route('products.index') }}" title="Retourner aux produit" >Retourner aux produit</a></p>

@endsection