@extends("layouts.app")
@section("title", "Tous les documents")
@section("content")

	<h1>Tous vos produit</h1>

	<div>
		<form action="/search3" method="GET" role="search">
			<div>
			<p>Rechercher le nom d'un produit</p>
			<input type="text" name="q" placeholder="Exemple : Panier de basket">
			<button type="submit">Go!</button>
			</div>
		</form>
	</div>
	<p class="my-3">
		<!-- Lien pour créer un nouveau doc : "product.create" -->
		<button type="button" class="btn btn-outline-info btn-lg px-4 me-sm-3 fw-bold">
		<a href="{{ route('products.create') }}" title="Créer un produit" >Créer un nouveau produit</a>
		</button>
	</p>

	<!-- Le tableau pour lister les produit -->
	<div class="col-lg-2 mx-auto">
	<table border="3" >
		<thead>
			<tr>
				<th>Nom</th>
				<th colspan="2" >Opérations</th>
			</tr>
		</thead>
		<tbody>
			<!-- On parcourt la collection de customers -->
			@foreach ($products as $product)
			<tr>
				<td>
					<!-- Lien pour afficher un customer : "products.show" -->
					<a href="{{ route('products.show', $product) }}" title="Lire l'article" >{{ $product->name }}</a>
				</td>
				<td>
					<!-- Lien pour modifier un customer : "product.edit" -->
					<a href="{{ route('products.edit', $product) }}" title="Modifier l'article" >Modifier</a>
				</td>
				<td>
					<!-- Formulaire pour supprimer un Post : "products.destroy" -->
					<form method="POST" action="{{ route('products.destroy', $product) }}" >
						<!-- CSRF token -->
						@csrf
						<!-- <input type="hidden" name="_method" value="DELETE"> -->
						@method("DELETE")
						<input type="submit" value="x Supprimer" >
					</form>
				</td>
			</tr>
			@endforeach
		</tbody>
	</table>
	<p><a href="/" title="Retourner a l'accueil" >Retourner a l'accueil</a></p>
	</div>
@endsection