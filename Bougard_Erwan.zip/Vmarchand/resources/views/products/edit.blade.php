@extends("layouts.app")
@section("title", "Editer un document")
@section("content")

	<h1>Editer un produit </h1>

	<!-- Si nous avons un doc $customer -->
	@if (isset($product))

	<!-- Le formulaire est géré par la route "products.update" -->
	<form method="POST" action="{{ route('products.update', $product) }}" enctype="multipart/form-data" >

		<!-- <input type="hidden" name="_method" value="PUT"> -->
		@method('PUT')

	@else

	<!-- Le formulaire est géré par la route "products.store" -->
	<form method="POST" action="{{ route('products.store') }}" enctype="multipart/form-data" >

	@endif

		<!-- Le token CSRF -->
		@csrf
		
		<p>
			<label for="name" >Nom</label><br/>

			<!-- S'il y a un $customer->title, on complète la valeur de l'input -->
			<input type="text" name="name" value="{{ isset($product->name) ? $product->name : old('name') }}"  id="name" placeholder="Le nom du produit" >

			<!-- Le message d'erreur pour "nom" -->
			@error("name")
			<div>{{ $message }}</div>
			@enderror
		</p>

        <p>
			<label for="price" >prix</label><br/>

			<!-- S'il y a un $products->price, on complète la valeur de l'input -->
			<input type="text" name="price" value="{{ isset($product->price) ? $product->price : old('price') }}"  id="price" placeholder="le prix du produit" >

			<!-- Le message d'erreur pour "nom" -->
			@error("price")
			<div>{{ $message }}</div>
			@enderror
		</p>
        <p>
			<label for="stock" >Stock</label><br/>

			<!-- S'il y a un $products->stock, on complète la valeur de l'input -->
			<input type="text" name="stock" value="{{ isset($product->stock) ? $product->stock : old('stock') }}"  id="stock" placeholder="le nombre de produit en stock" >

			<!-- Le message d'erreur pour "stock" -->
			@error("stock")
			<div>{{ $message }}</div>
			@enderror
		</p>
		
		<p>
			<label for="content" >Description</label><br/>

			<!-- S'il y a un $product->content, on complète la valeur du textarea -->
			<textarea name="content" id="content" lang="fr" rows="10" cols="50" placeholder="Les informations du produit" >{{ isset($product->content) ? $product->content : old('content') }}</textarea>

			<!-- Le message d'erreur pour "description" -->
			@error("content")
			<div>{{ $message }}</div>
			@enderror
		</p>

		<input type="submit" name="valider" value="Valider" >

	</form>
	
@endsection