<!DOCTYPE html>
<html lang="fr">
<head>
	<meta charset="utf-8">
	@vite(['resources/js/app.css', 'resources/js/app.js'])
	<!-- Le titre de la page -->
	<title>@yield("title")</title>
</head>
<body class="bg-dark">
	<div class="bg-dark text-secondary px-4 py-5 text-center">
		<div class="py-5">
		  <!-- Le contenu -->
			@yield("content")
		</div>
	  </div>
<script src="{{asset("js/app.js")}}"></script>
</body>
</html>