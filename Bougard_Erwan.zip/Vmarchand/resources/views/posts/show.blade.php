@extends("layouts.app")
@section("title", $post->title)
@section("content")

	<h1>Titre du document : {{ $post->title }}</h1>

	<p>Type de document : {{ $post->type }}</p>
	<p>Apercu du document </p>
	<img src="{{ asset('storage/'.$post->picture) }}" alt="Image de couverture" style="max-width: 300px;">
	<p>Description du document</p>
	<div>{{ $post->content }}</div>

	<p><a href="{{ route('posts.index') }}" title="Retourner aux articles" >Retourner aux documents</a></p>

@endsection