@extends("layouts.app")
@section("title", "Tous les documents")
@section("content")

	<h1>Tous vos documents</h1>
	<!-- Recherche de type de documents-->
	<div>
		<form action="/search" method="GET" role="search">
			<div>
			<p>Rechercher un type de document</p>
			<input type="text" name="q" placeholder="Exemple : Facture">
			<button type="submit">Go!</button>
			</div>
		</form>
	</div>
	<div class="my-3">
	<p>
		<!-- Lien pour créer un nouveau doc : "posts.create" -->
		<button type="button" class="btn btn-outline-info btn-lg px-4 me-sm-3 fw-bold">
		<a href="{{ route('posts.create') }}" title="Créer un article" >Créer un nouveau document</a>
		</button>
	</p>
	</div>
	<!-- Le tableau pour lister les articles/posts -->
	<div class="col-lg-2 mx-auto">
	<table border="3" >
		<thead>
			<tr>
				<th>Titre</th>
				<th>Type</th>
				<th colspan="3" >Opérations</th>
			</tr>
		</thead>
		<tbody>
			<!-- On parcourt la collection de Post -->
			@foreach ($posts as $post)
			<tr>
				<td>
					<!-- Lien pour afficher un Post : "posts.show" -->
					<a href="{{ route('posts.show', $post) }}" title="Lire l'article" >{{ $post->title }}</a>
				</td>
				<td>
					<p>{{ $post->type }}</p>
				</td>
				<td>
					<!-- Lien pour modifier un Post : "posts.edit" -->
					<a href="{{ route('posts.edit', $post) }}" title="Modifier l'article" >Modifier</a>
				</td>
				<td>
					<!-- Formulaire pour supprimer un Post : "posts.destroy" -->
					<form method="POST" action="{{ route('posts.destroy', $post) }}" >
						<!-- CSRF token -->
						@csrf
						<!-- <input type="hidden" name="_method" value="DELETE"> -->
						@method("DELETE")
						<input type="submit" value="x Supprimer" >
					</form>
				</td>
			</tr>
			@endforeach
		</tbody>
	</table>
	<p><a href="/" title="Retourner a l'accueil" >Retourner a l'accueil</a></p>
	</div>
@endsection