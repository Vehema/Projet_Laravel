<!DOCTYPE html>
<html lang="fr">
<head>
<title>Vmarchand homepage</title>
<meta charset="utf-8">
@vite(['resources/js/app.css', 'resources/js/app.js'])
</head>
<body class="bg-dark">

<div class="bg-dark text-secondary px-4 py-5 text-center">
    <div class="py-5">
      <h1 class="display-5 fw-bold text-white">Vos documents</h1>
      <div class="col-lg-6 mx-auto">
        <div class="d-grid gap-2 d-sm-flex justify-content-sm-center">
          <button type="button" class="btn btn-outline-light btn-lg px-4"><a href="{{ route('posts.index') }}" title="Documents personnel" >Documents personnel</a></button>
          <button type="button" class="btn btn-outline-light btn-lg px-4"><a href="{{ route('customers.index') }}" title="Documents clients" >Documents clients</a></button>
          <button type="button" class="btn btn-outline-light btn-lg px-4"><a href="{{ route('products.index') }}" title="Produits" >Produits</a></button>
        </div>
      </div>
    </div>
  </div>

</body>
</html>