@extends("layouts.app")
@section("title", "Tous les documents")
@section("content")

	<h1>Tous vos documents</h1>

	<div>
		<form action="/search2" method="GET" role="search">
			<div>
			<p>Rechercher le nom d'un client</p>
			<input type="text" name="q" placeholder="Exemple : Meunier">
			<button type="submit">Go!</button>
			</div>
		</form>
	</div>
	<p class="my-3">
		<!-- Lien pour créer un nouveau doc : "customers.create" -->
		<button type="button" class="btn btn-outline-info btn-lg px-4 me-sm-3 fw-bold">
		<a href="{{ route('customers.create') }}" title="Créer un article" >Créer un nouveau document</a>
		</button>
	</p>

	<!-- Le tableau pour lister les customers -->
	<div class="col-lg-2 mx-auto">
	<table border="3" >
		<thead>
			<tr>
				<th>Nom</th>
				<th colspan="2" >Opérations</th>
			</tr>
		</thead>
		<tbody>
			<!-- On parcourt la collection de customers -->
			@foreach ($customers as $customer)
			<tr>
				<td>
					<!-- Lien pour afficher un customer : "customer.show" -->
					<a href="{{ route('customers.show', $customer) }}" title="Lire l'article" >{{ $customer->name }}</a>
				</td>
				<td>
					<!-- Lien pour modifier un customer : "customer.edit" -->
					<a href="{{ route('customers.edit', $customer) }}" title="Modifier l'article" >Modifier</a>
				</td>
				<td>
					<!-- Formulaire pour supprimer un Post : "posts.destroy" -->
					<form method="POST" action="{{ route('customers.destroy', $customer) }}" >
						<!-- CSRF token -->
						@csrf
						<!-- <input type="hidden" name="_method" value="DELETE"> -->
						@method("DELETE")
						<input type="submit" value="x Supprimer" >
					</form>
				</td>
			</tr>
			@endforeach
		</tbody>
	</table>
	<p><a href="/" title="Retourner a l'accueil" >Retourner a l'accueil</a></p>
	</div>
@endsection