@extends("layouts.app")
@section("title", "Editer un document")
@section("content")

	<h1>Editer un document client </h1>

	<!-- Si nous avons un doc $customer -->
	@if (isset($customer))

	<!-- Le formulaire est géré par la route "customer.update" -->
	<form method="POST" action="{{ route('customers.update', $customer) }}" enctype="multipart/form-data" >

		<!-- <input type="hidden" name="_method" value="PUT"> -->
		@method('PUT')

	@else

	<!-- Le formulaire est géré par la route "customers.store" -->
	<form method="POST" action="{{ route('customers.store') }}" enctype="multipart/form-data" >

	@endif

		<!-- Le token CSRF -->
		@csrf
		
		<p>
			<label for="name" >Nom</label><br/>

			<!-- S'il y a un $customer->title, on complète la valeur de l'input -->
			<input type="text" name="name" value="{{ isset($customer->name) ? $customer->name : old('name') }}"  id="name" placeholder="Le nom du client" >

			<!-- Le message d'erreur pour "nom" -->
			@error("name")
			<div>{{ $message }}</div>
			@enderror
		</p>

        <p>
			<label for="email" >email</label><br/>

			<!-- S'il y a un $customer->email, on complète la valeur de l'input -->
			<input type="text" name="email" value="{{ isset($customer->email) ? $customer->email : old('email') }}"  id="email" placeholder="L'email du client" >

			<!-- Le message d'erreur pour "nom" -->
			@error("email")
			<div>{{ $message }}</div>
			@enderror
		</p>
		
		<p>
			<label for="description" >Description</label><br/>

			<!-- S'il y a un $customer->description, on complète la valeur du textarea -->
			<textarea name="description" id="description" lang="fr" rows="10" cols="50" placeholder="Les informations du client" >{{ isset($customer->description) ? $customer->description : old('description') }}</textarea>

			<!-- Le message d'erreur pour "description" -->
			@error("description")
			<div>{{ $message }}</div>
			@enderror
		</p>

		<input type="submit" name="valider" value="Valider" >

	</form>
	
@endsection