@extends("layouts.app")
@section("title", $customer->name)
@section("content")

	<h1>Nom du client : {{ $customer->name }}</h1>
	
	<h1>Email du client : {{ $customer->email }}</h1>
	<p>Description</p>
	<div>{{ $customer->description }}</div>

	<p><a href="{{ route('customers.index') }}" title="Retourner aux documents" >Retourner aux documents</a></p>

@endsection